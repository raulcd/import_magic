print(__name__)
print('main!!!')
